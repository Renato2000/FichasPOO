public class VeiculoRepetidoException extends Exception{
	public VeiculoRepetidoException(String msg){
		super(msg);
	}
}