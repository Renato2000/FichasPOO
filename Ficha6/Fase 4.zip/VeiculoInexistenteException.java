public class VeiculoInexistenteException extends Exception{
	public VeiculoInexistenteException(String msg){
		super(msg);
	}
}