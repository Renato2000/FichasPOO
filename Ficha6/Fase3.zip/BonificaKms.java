public interface BonificaKms{
	void setPontosKm(int pontosKm);
	int getPontosKm();
	int getPontosAcomulados();
}